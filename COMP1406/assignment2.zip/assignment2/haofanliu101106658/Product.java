public class Product {
    public Product(double price, int quantity) {
        this.price = price;
        this.stockQuantity = quantity;
    }

    public double sellUnits(int amount) {
        if (amount <= stockQuantity) {
            stockQuantity -= amount;
            soldQuantity += amount;
            return amount * price;
        } else {
            return 0;
        }
    }

    @Override
    public String toString() {
        return "Product{" +
                "price=" + price +
                ", stockQuantity=" + stockQuantity +
                ", soldQuantity=" + soldQuantity +
                '}';
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStockQuantity() {
        return stockQuantity;
    }

    public void setStockQuantity(int stockQuantity) {
        this.stockQuantity = stockQuantity;
    }

    public int getSoldQuantity() {
        return soldQuantity;
    }

    public void setSoldQuantity(int soldQuantity) {
        this.soldQuantity = soldQuantity;
    }

    private double price;
    private int stockQuantity;
    private int soldQuantity;

}
