public class Laptop extends Product {

    public Laptop(double price, int quantity, double cpuSpeed, int ram, boolean ssd, int storage, double screenSize) {
        super(price, quantity);
        this.cpuSpeed = cpuSpeed;
        this.ram = ram;
        this.ssd = ssd;
        this.storage = storage;
        this.screenSize = screenSize;
    }

    @Override
    public String toString() {
        String driveCategory;
        if(ssd) driveCategory="SSD";
        else driveCategory="HDD";

        return screenSize+" inch Laptop PC with "+cpuSpeed+"ghz CPU, "+ram+"GB RAM, "+storage+"GB "+driveCategory+" drive. "
                +"("+getPrice()+" dollars each, "+getStockQuantity()+" in stock, "+getSoldQuantity()+" sold)";
    }

    public double getCpuSpeed() {
        return cpuSpeed;
    }

    public void setCpuSpeed(double cpuSpeed) {
        this.cpuSpeed = cpuSpeed;
    }

    public int getRam() {
        return ram;
    }

    public void setRam(int ram) {
        this.ram = ram;
    }

    public boolean isSsd() {
        return ssd;
    }

    public void setSsd(boolean ssd) {
        this.ssd = ssd;
    }

    public int getStorage() {
        return storage;
    }

    public void setStorage(int storage) {
        this.storage = storage;
    }

    public double getScreenSize() {
        return screenSize;
    }

    public void setScreenSize(double screenSize) {
        this.screenSize = screenSize;
    }

    private double cpuSpeed;
    private int ram;
    private boolean ssd;
    private int storage;
    private double screenSize;


}
