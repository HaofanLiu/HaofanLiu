import java.util.Scanner;

public class ElectronicStore {
    public ElectronicStore(String name) {
        this.name = name;
        this.products = new Product[MAX_PRODUCTS];
        this.currentProductIndex = -1;
        this.revenue = 0;
    }

    boolean addProduct(Product p) {
        if (currentProductIndex < MAX_PRODUCTS - 1) {
            products[++currentProductIndex] = p;
            return true;
        } else {
            return false;
        }
    }

    void sellProducts() {
        System.out.println(name + " Electronic's Stock Is:\n");
        for (int i = 0; i <= currentProductIndex; ++i) {
            System.out.println(i + ". " + products[i]);
        }
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please input the index and amount:");
        while (scanner.hasNextInt()) {
            int item = scanner.nextInt();
            int amount = scanner.nextInt();
            if (0 <= item && item <= currentProductIndex) {
                if (amount >=0 && amount <= products[item].getStockQuantity()) {
                    sellProducts(item, amount);
                    System.exit(0);
                } else {
                    System.out.println("We dont have enough...");
                }
            } else {
                System.out.println("The Item you selected: (" + item + ") is invalid.");
                System.exit(0);
            }
        }

    }

    void sellProducts(int item, int amount) {
        if (0 <= item && item <= currentProductIndex) {
            if (amount>=0 && amount <= products[item].getStockQuantity()) {
                revenue += products[item].getPrice() * amount;
                products[item].sellUnits(amount);
            }
        }

    }

    void printStock() {
        for (int i = 0; i <= currentProductIndex; ++i) {
            System.out.println(i + ". " + products[i]);
        }
    }

    public String getName() {
        return name;
    }

    public double getRevenue() {
        return revenue;
    }

    private final int MAX_PRODUCTS = 10;
    private String name;
    private double revenue;
    private Product[] products;
    private int currentProductIndex;


    public static void main(String[] args) {
        ElectronicStore store = new ElectronicStore("Jian");
        Fridge f = new Fridge(600, 10, 125, "White", "Sub Zero", 23, true);
        store.addProduct(f);
        store.sellProducts();
    }
}
