public class Fridge extends Product {

    public Fridge(double price, int quantity, int wattage, String color, String brand, double cubicFeet, boolean hasFreezer) {
        super(price, quantity);
        this.wattage = wattage;
        this.color = color;
        this.brand = brand;
        this.cubicFeet = cubicFeet;
        this.hasFreezer = hasFreezer;
    }

    @Override
    public String toString() {
        String freezer="";
        if(hasFreezer) freezer="with Freezer ";
        return cubicFeet+" cu. ft. "+brand+" Fridge "+freezer+"("+color+", "+wattage+" watts) "
                +"("+getPrice()+" dollars each, "+getStockQuantity()+" in stock, "+getSoldQuantity()+" sold)";

    }

    public int getWattage() {
        return wattage;
    }

    public void setWattage(int wattage) {
        this.wattage = wattage;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public double getCubicFeet() {
        return cubicFeet;
    }

    public void setCubicFeet(double cubicFeet) {
        this.cubicFeet = cubicFeet;
    }

    public boolean isHasFreezer() {
        return hasFreezer;
    }

    public void setHasFreezer(boolean hasFreezer) {
        this.hasFreezer = hasFreezer;
    }

    private int wattage;
    private String color;
    private String brand;
    double cubicFeet;
    boolean hasFreezer;


}
