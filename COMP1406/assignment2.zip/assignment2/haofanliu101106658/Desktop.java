public class Desktop extends Product {

    public Desktop(double price, int quantity, double cpuSpeed, int ram, boolean ssd, int storage, String profile) {
        super(price, quantity);
        this.cpuSpeed = cpuSpeed;
        this.ram = ram;
        this.ssd = ssd;
        this.storage = storage;
        this.profile = profile;
    }

    @Override
    public String toString() {
        String driveCategory;
        if(ssd) driveCategory="SSD";
        else driveCategory="HDD";

        return profile+" Desktop PC with "+cpuSpeed+"ghz CPU, "+ram+"GB RAM, "+storage+"GB "+driveCategory+" drive. "
                +"("+getPrice()+" dollars each, "+getStockQuantity()+" in stock, "+getSoldQuantity()+" sold)";
    }

    private double cpuSpeed;
    private int ram;
    private boolean ssd;
    private int storage;
    private String profile;

    public double getCpuSpeed() {
        return cpuSpeed;
    }

    public void setCpuSpeed(double cpuSpeed) {
        this.cpuSpeed = cpuSpeed;
    }

    public int getRam() {
        return ram;
    }

    public void setRam(int ram) {
        this.ram = ram;
    }

    public boolean isSsd() {
        return ssd;
    }

    public void setSsd(boolean ssd) {
        this.ssd = ssd;
    }

    public int getStorage() {
        return storage;
    }

    public void setStorage(int storage) {
        this.storage = storage;
    }

    public String getProfile() {
        return profile;
    }

    public void setProfile(String profile) {
        this.profile = profile;
    }
}
