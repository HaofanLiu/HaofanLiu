public class ToasterOven extends Product {

    public ToasterOven(double price, int quantity, int wattage, String color, String brand, int width, boolean convection) {
        super(price, quantity);
        this.wattage = wattage;
        this.color = color;
        this.brand = brand;
        this.width = width;
        this.convection = convection;
    }

    @Override
    public String toString() {
        String hasConvection="";
        if(convection) hasConvection=" with convection";
        return width+" inch "+brand+" Toaster"+hasConvection+" ("+color+", "+wattage+" watts) "
                +"("+getPrice()+" dollars each, "+getStockQuantity()+" in stock, "+getSoldQuantity()+" sold)";
    }

    public int getWattage() {
        return wattage;
    }

    public void setWattage(int wattage) {
        this.wattage = wattage;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public boolean isConvection() {
        return convection;
    }

    public void setConvection(boolean convection) {
        this.convection = convection;
    }

    private int wattage;
    private String color;
    private String brand;
    private int width;
    private boolean convection;
}
