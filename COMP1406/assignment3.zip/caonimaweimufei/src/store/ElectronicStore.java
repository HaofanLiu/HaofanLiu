package store;

import java.util.Arrays;
import java.util.Objects;

public class ElectronicStore {
    public final int Max = 10;
    private int cut;
    String name;
    product[]stock;

    public product[] getStock() {
        return stock;
    }

    public String getName() {
        return name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ElectronicStore that = (ElectronicStore) o;
        return Max == that.Max &&
                cut == that.cut &&
                Objects.equals(name, that.name) &&
                Arrays.equals(stock, that.stock);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(Max, cut, name);
        result = 31 * result + Arrays.hashCode(stock);
        return result;
    }
}
