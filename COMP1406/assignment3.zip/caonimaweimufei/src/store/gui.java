package store;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableSetValue;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import javax.swing.*;

public class gui extends Application{
    private Button Reset;
    private Object newValue;

    public static void main(String[]args){

    }

    @Override
    public void start(Stage stage) throws Exception {
        gui Gui = gui.createStore();
        Pane ap = new Pane();
        Label storesummary = new Label("Store Summary");
        Label sales = new Label("#Sale:");
        Label revenue = new Label("Revenue:");
        Label $sale = new Label("$/Sale:");
        Label MPI = new Label("Most Popular Items:");
        Label storestock = new Label("Store Stock");
        Label Cart = new Label("Current Cart");
        sales.setPrefSize(60,10);
        revenue.setPrefSize(60,10);
        $sale.setPrefSize(60,10);
        storestock.setPrefSize(120,30);
        Cart.setPrefSize(300,30);

        TextField Sale = new TextField("0");
        TextField Revenue = new TextField("0");
        TextField SALE = new TextField("0");

        Button addtocart = new Button("Add to Cart");
        Button removefromcart = new Button("Remove from Cart");
        Button Reset = new Button("Reset Store");
        Button completesale = new Button("Complete Sale");

        Sale.setPrefWidth(120);
        revenue.setPrefWidth(120);
        SALE.setPrefWidth(120);

        addtocart.relocate(280,350);
        addtocart.setPrefSize(120,40);
        addtocart.setDisable(true);
        addtocart.setOnAction();{
public void changed(ObservableSetValue){
}
        if (newValue != null){
        addtocart.setDisable(false);
           else{
            addtocart.setDisable(true);

        }
    }
        

    private static gui createStore() {
    }

    private static gui Store() {
    }
}